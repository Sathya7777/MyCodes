sap.ui.define([
    'jquery.sap.global',
    "sap/dm/dme/podfoundation/controller/PluginViewController",
    "sap/ui/model/json/JSONModel"
], function (jQuery, PluginViewController, JSONModel) {
    "use strict";
    var that="";
    return PluginViewController.extend("shoubii.custom.plugins.Tagvalues.Tagvalues.controller.MainView", {
        onInit: function () {
            that=this;
            PluginViewController.prototype.onInit.apply(this, arguments);

 
        },
        onAfterRendering: function () {
            var that = this;
        
            jQuery.sap.includeScript("https://www.gstatic.com/charts/loader.js", "NewId", function () {
                google.charts.load('current', {
                    'packages': ['gauge']
                });
        
                google.charts.setOnLoadCallback(function () {
                    var data = google.visualization.arrayToDataTable([['Label', 'Value'], ['Temp', 1]]);
                    var options = {
                        width: 1000,
                        height: 500,
                        redFrom: 90, 
                        redTo: 100,
                        yellowFrom: 80,
                        yellowTo: 90,
                        minorTicks: 10,
			            max:100,
                        
                    };
                    var chart = new google.visualization.Gauge(document.getElementById(that.getView().byId("chart_div").sId));
                    chart.draw(data, options);
        
                    // Function to update the gauge chart with new data
                    function updateGauge(value) {
                        data.setValue(0, 1, value);
                        chart.draw(data, options);
                    }
        
                    // AJAX call to fetch dynamic data (you should replace this with your actual API endpoint)
                    function fetchData() {
                        var url = "/sapdmdmepod/dmi/pe/api/v1/process/processDefinitions/start?key=" + "REG_c1c372cd-f144-4b16-937e-7b34d82299c8" + "&async=false&logLevel=";
                        // Simulating an AJAX call to get data
                        $.ajax({
                            url: url,
                            method: 'POST',
                            dataType: 'json',
                            success: function (response) {
                                // Assuming the API response contains the new value as response.data.value
                                var newValue = response.data.value;
                                updateGauge(newValue);
                            },
                            error: function (error) {
                                console.error('Error fetching data:', error);
                            }
                        });
                    }
                    
        
                    // Initially, fetch and update the gauge with data
                    fetchData();
        
                    // Set an interval to periodically update the gauge with new data
                    setInterval(function () {
                        fetchData();
                    }, 1000); // Update every 1 second (adjust this interval as needed)
                });
            });
        },

        onBeforeRenderingPlugin: function () {
        },

        isSubscribingToNotifications: function () {

            var bNotificationsEnabled = true;

            return bNotificationsEnabled;
        },


        getCustomNotificationEvents: function (sTopic) {
            //return ["template"];
        },


        getNotificationMessageHandler: function (sTopic) {

            //if (sTopic === "template") {
            //    return this._handleNotificationMessage;
            //}
            return null;
        },

        _handleNotificationMessage: function (oMsg) {

            var sMessage = "Message not found in payload 'message' property";
            if (oMsg && oMsg.parameters && oMsg.parameters.length > 0) {
                for (var i = 0; i < oMsg.parameters.length; i++) {

                    switch (oMsg.parameters[i].name) {
                        case "template":

                            break;
                        case "template2":
                    }
                }
            }
        },
        onExit: function () {
            PluginViewController.prototype.onExit.apply(this, arguments);


        }
    });
});